package M2;

import java.io.*; 
import java.net.*; 

public class TCPServer { 

  public static void main(String argv[]) throws Exception 
    { 
    

      ServerSocket welcomeSocket = new ServerSocket(6789); 
      System.out.println("The server is ready for chatting");
      Socket socket = welcomeSocket.accept();
      BufferedReader keyRead = new BufferedReader(new InputStreamReader(System.in));
      OutputStream output = socket.getOutputStream();
      PrintWriter write = new PrintWriter(output,true);
      InputStream input = socket.getInputStream();
      BufferedReader read = new BufferedReader(new InputStreamReader(input));
      String sentence = keyRead.readLine();
    
    	  String receiveMessage, sendMessage;          
      while(true) { 
    	  BufferedReader b = new BufferedReader(new InputStreamReader(System.in));
          if((receiveMessage = read.readLine()) != null)  
          {
             System.out.println(receiveMessage);         
          }         
          sendMessage = keyRead.readLine(); 
          write.println(sendMessage);             
          write.flush();
  
           /* Socket connectionSocket = welcomeSocket.accept(); 
    	  
           BufferedReader inFromClient =  new BufferedReader(new InputStreamReader(connectionSocket.getInputStream())); 
           DataOutputStream  outToClient = new DataOutputStream(connectionSocket.getOutputStream()); 

                 clientSentence = inFromClient.readLine(); 

                 capitalizedSentence = clientSentence.toUpperCase() + '\n'; 

                 outToClient.writeBytes(capitalizedSentence);*/ 
              } 
          } 
    }
  


