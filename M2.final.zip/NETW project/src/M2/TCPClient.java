package M2;

import java.io.*; 
import java.net.*; 
public class TCPClient { 

    public static void main(String argv[]) throws Exception 
    { 
        String sentence; 
        String modifiedSentence;    

        BufferedReader inFromUser = new BufferedReader(new InputStreamReader(System.in)); 
        sentence=inFromUser.readLine();

        Socket clientSocket = new Socket("localhost", 6789); 
//if another device, we will take the ip address from the command prompt and check the ip of the other device in the same network and replace it instead of localhost 
        OutputStream outToServer = new DataOutputStream(clientSocket.getOutputStream()); 
        PrintWriter write = new PrintWriter(outToServer, true);
        BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream())); 
        String receiveMessage, sendMessage;  
        if(sentence.equals("CONNECT")){
      	  System.out.println("K");
        while(true)
        {
           sendMessage = inFromUser.readLine();  // keyboard reading
           write.println(sendMessage);       // sending to server
           write.flush();                    // flush the data
           if((receiveMessage = inFromUser.readLine()) != null) //receive from server
           {
               System.out.println(receiveMessage); // displaying at DOS prompt
           }         
           if(sendMessage.equals("CLOSE"))
               clientSocket.close();
        }
        
          


          } }
      } 

